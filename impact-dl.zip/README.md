TO DO before publishing: 

general
2 - micromamba envs: Sei and modisco
3 - VEP container - pull from ensembl \ add place holder. also - docker or udocker?


pre pred
1 - put placeholders in config.yaml, filter_mock_datasets_vcfs.sh, 
6 - add usage statemanets both with snakemake and without 
5 - add link for downloading the gnomad file 


prediction
decide if I want to upload the streaming files. if not delete:
run_streaming_sei_pipeline.sh
streaming_sei_no_race.py
turn the 2 slurm scripts to ***slurm examples for both array and single ***
7 - run once again with the regular pred and aggregation scripts

ontology enrichmnet
- decide if i want to put the 4 ontologies code _ the ancestor collapse code, or if I want to just provide the matched_sup2 files - or both. if i provide four_ontologies - generalize the config at the top
- per the last decision - same for ancestor and collapse - delete config and also make availablethe collapsed matches for ontologies...
- the only file in the ont matching we will give for sure is the run complete enr pipeine - in it we need to make the config general as well :) - anyways generalize n and delete the different_n_full_ont_pipleine



plotting
8 - delete plot related scripts? 


now the streaming in the new dirs isnt working - make sure it runs...